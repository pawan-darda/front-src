from django.http import HttpResponse 
from DjangoWebSite.utils import  session_maker
from front_db.asgard_db import db_wrapper
from sqlalchemy import desc
from django.shortcuts import render_to_response
from django.template.loader import render_to_string
from front_utils.versions import get_version
from django.core.mail import EmailMultiAlternatives
from DjangoWebSite.settings import NOTIFIER_DEBUG
from django.db.models import Avg
from sqlalchemy import desc, and_, or_, except_, distinct
from math import sqrt, pow
import urllib2
from xml.dom.minidom import parse

##########################################################
#             Configurations for notifiers               #
##########################################################
class EqTrading ():
    def __init__(self,quote_replies,precalc_quote_replies,user_mode_time,modify_order_replies,gc_number_of_collections,email_list):
        self.quote_replies = quote_replies
        self.precalc_quote_replies = precalc_quote_replies
        self.user_mode_time = user_mode_time
        self.modify_order_replies = modify_order_replies
        self.gc_number_of_collections = gc_number_of_collections
        self.email_list = email_list
        
class RegressionAlert ():
    def __init__(self,labels,measures,email_list):
        self.labels=labels
        self.measures=measures
        self.email_list = email_list

class ActiveMQ ():
    def __init__(self,qCount,dqCount,qName,qConsumer,qSize,status):
        self.qCount = qCount
        self.dqCount = dqCount
        self.qName = qName
        self.qConsumer = qConsumer
        self.qSize = qSize
        self.status = status    
        
debug_mail_ids =["amit.rathi@sungard.com","shashank.ashtikar@sungard.com","pawan.darda@sungard.com","milind.patil@sungard.com","laurent.ploix@sungard.com","Sheetal.Kulkarni@sungard.com"]
cc_mail_ids = ["amit.rathi@sungard.com","pawan.darda@sungard.com"]

emails_eqtrading =["magnus.helsing@sungard.com", "shashank.ashtikar@sungard.com"]
scenario_name_eqtrading = ["equity_trading.xls"]

parameter_eqtrading = EqTrading(365000,600,1600,235000,33,emails_eqtrading)
special_parameter_eqtrading = {"4.7": EqTrading(365000,600,1600,235000,30,emails_eqtrading)}

emails_regression_alert = ['shashank.ashtikar@sungard.com','Laurent.Ploix@sungard.com', 'per.brandt@sungard.com', 'riku.eronen@sungard.com', 'ola.knutsson@sungard.com', 'Johan.Fredriksson@sungard.com']
parameter_regression = {'alerter_old_names': RegressionAlert(['Start up diff after GC','Start up diff before GC'],['gc_used_kilobytes', 'used_cpu_s', 'nb_nodes'],emails_regression_alert),
                        'alerter_new_names': RegressionAlert(['Effect of loading sheet after GC','Effect of loading sheet before GC','Measure of loading sheet after GC'],\
                                                    ['gc_used_kilobytes', 'used_cpu_s', 'nb_nodes'],emails_regression_alert)}
            
regression_build = 10


##########################################################
#            Analysis for ActiveMQ monitor               #
##########################################################

def active_mq_monitor ():
    mail_obj_list = []
    conn = urllib2.urlopen ("http://activemq.tqa.corp:8161/admin/xml/queues.jsp")
    doc = parse (conn)
    rss_elt = doc.documentElement

    assert rss_elt.tagName == 'queues'
    child = rss_elt.firstChild
    qDetails = []
    while (child is not None):
        if hasattr (child, "tagName") and child.tagName == "queue":
            stats = child.getElementsByTagName('stats')[0]
            
            #Getting queue details name, message enqueued, message dequeued, number of consumers, pending messages.
            qName = child.getAttribute('name')
            qCount =  int(stats.getAttribute('enqueueCount'))
            dqCount = int(stats.getAttribute('dequeueCount'))
            qConsumer = int(stats.getAttribute('consumerCount'))
            qSize = int(stats.getAttribute('size'))
            status = ''
            #if queue size greater than 0 messages are pending. 
            if qSize > 0:
                status = 'msg_pending'
            if (not 'WBrequest' in qName) and qSize>=3:
                qDetails.append(ActiveMQ (qCount,dqCount,qName,qConsumer,qSize,status))
        child = child.nextSibling
    if len(qDetails)>0:     
        from_email= 'activemq@tqa.corp'
        tos = debug_mail_ids
        subject = 'Pending messages on queues.'
        email_response =  render_to_response('notify_activemq.xhtml',{'qDetails':qDetails})
        text_content = 'This is an important message.'
        
        msg = EmailMultiAlternatives(subject, text_content, from_email, tos)
        msg.attach_alternative (email_response.content, "text/html")
        mail_obj_list.append(msg)
    return mail_obj_list     


#####################################################9#####
#          Analysis for Regression Generation            #
##########################################################

def regression_alert(batch):
    mail_obj_list = []
    with session_maker.asgard_read_uncommited_session_provider.get_session () as session:
        version_data = get_version('PRIME', batch.version.name)
        
        sc_query = session.query(db_wrapper.ReportMetrics.sc_name).distinct ()
        sc_query= sc_query.filter (db_wrapper.ReportMetrics.br_name == batch.name)
        sc_query= sc_query.filter (db_wrapper.ReportMetrics.main == version_data.main)
        sc_query= sc_query.filter (db_wrapper.ReportMetrics.sub == version_data.sub)
        sc_query= sc_query.filter (db_wrapper.ReportMetrics.abn == 0)
        sc_query= sc_query.filter (db_wrapper.ReportMetrics.bn == version_data.bn)
        sc_data = sc_query.all()

        hist_data_query = session.query (db_wrapper.ReportMetrics)
        hist_data_query = hist_data_query.with_hint(db_wrapper.ReportMetrics, ' with(noexpand) ')
        hist_data_query = hist_data_query.filter (db_wrapper.ReportMetrics.main == version_data.main)
        hist_data_query = hist_data_query.filter (db_wrapper.ReportMetrics.sub == version_data.sub)
        hist_data_query = hist_data_query.filter (db_wrapper.ReportMetrics.f_actual != None)
        hist_data_query = hist_data_query.order_by (desc(db_wrapper.ReportMetrics.bn))
        
        #LOOP TO GET MEASURES,LABEL AND SCENARIO SPECIFIC FILTER
        for key,value in parameter_regression.items():
            if version_data.abn != 0:
                return mail_obj_list
            # Skipping track 2009.2
            elif version_data.main == 4 and version_data.sub == 4 :
                return mail_obj_list
            response_list = []
            for scenario_name in sc_data:
                avg_db_query = hist_data_query.filter (db_wrapper.ReportMetrics.sc_name == scenario_name[0])   
                check_query = avg_db_query.filter (db_wrapper.ReportMetrics.st_label.in_ (value.labels))
                check_query = check_query.filter (db_wrapper.ReportMetrics.bn == version_data.bn)
                check_count = check_query.count()
                if check_count:
                    for label in value.labels:
                        for measure in value.measures:
                            avg_db_query = avg_db_query.filter (db_wrapper.ReportMetrics.bn <= version_data.bn)
                            avg_db_query = avg_db_query.filter (db_wrapper.ReportMetrics.st_label == label)
                            avg_db_query = avg_db_query.filter (db_wrapper.ReportMetrics.col_name == measure)
                            build_data = avg_db_query[:regression_build+2]
                            if len(build_data)== regression_build+2:
                                all_value_list = []
                                historic_data = []
                                
                                for build in build_data:
                                    temp_build_dict = {}
                                    version_string = "%s-%s.%s.%s"%(build.nice,build.main,build.sub,build.bn)
                                    temp_build_dict['version'] = version_string
                                    temp_build_dict['value'] = round (build.f_actual,2)
                                    historic_data.append(temp_build_dict)
                                    all_value_list.append(build.f_actual)  
                                
                                sigma_value_list = all_value_list[2:]
                                average = sum(sigma_value_list)/len(sigma_value_list)
                                
                                deviation = 0.0
                                for value_val in sigma_value_list:
                                    deviation = deviation + (pow((average-value_val),2))
                                standard_deviation = sqrt (deviation/(len(sigma_value_list)-1))
                                
                                upper_limit = average + (3*standard_deviation)
                                lower_limit = average - (3*standard_deviation)
                                
                                build_but_one = all_value_list[1]
                                build_interested = all_value_list[0]
                                
                                per_change = (build_interested - average)/ average * 100
                                if ((build_but_one < lower_limit) and (build_interested < lower_limit)) \
                                    or ((build_but_one > upper_limit) and (build_interested > upper_limit)):
                                    if abs(per_change) > 5:  # Add to response list only if change is greater than 5%
                                        temp_response =  render_to_string('regression_alert_list.xhtml',
                                                                   {'scenario_name': scenario_name[0],
                                                                    'label': label,
                                                                    'measure': measure,
                                                                    'value': round(build_interested,2),
                                                                    'average': round(average,2),
                                                                    'past': historic_data,
                                                                    'version_data':version_data,
                                                                    'percentage_change':round(per_change,2)
                                                                    })
                                        response_list.append(temp_response)
                            #End measures loop
                        #End labels loop
                    #End of check loop
                #End scenarios loop

            if response_list:
                from_email= 'donotreply@tqa.corp'
                tos =  emails_regression_alert
                subject = 'Performance analysis report for "%s" set, on version %s.%s.%s' %(batch.name, version_data.main, version_data.sub, version_data.bn)
                actual_mail_recipient = []
                if NOTIFIER_DEBUG:
                    actual_mail_recipient = tos
                    tos = debug_mail_ids    
                else:
                    tos = tos + cc_mail_ids               
                email_response =  render_to_response('regression_notifier.xhtml',
                               {'response_list':response_list,
                                'actual_mail_recipient':actual_mail_recipient
                                })
                    
                text_content = 'This is an important message.'
                
                msg = EmailMultiAlternatives(subject, text_content, from_email, tos)
                msg.attach_alternative (email_response.content, "text/html")
                #msg.send()
                mail_obj_list.append(msg)
            #End alerter loop
    return mail_obj_list

##########################################################
#             Analysis for EqTradingAlert                #
##########################################################

def eq_trading_alert (batch):
    mail_obj_list = []
    #Get the configuration from the config file.
    version = batch.version
    version_name = version.name
    version_data = get_version('PRIME',version_name)

    # Skipping logic for prime versions
    if version_data.abn != 0:
        return mail_obj_list
    elif version_data.main == 4 and version_data.sub <= 6 :
        return mail_obj_list
    elif version_data.main <= 3:
        return mail_obj_list
     
    track = "%s.%s"%(version_data.main, version_data.sub)

    if special_parameter_eqtrading.has_key(track):
        expected_parameters = special_parameter_eqtrading[track]
    else:
        expected_parameters = parameter_eqtrading
    
    expected_quote_replies = expected_parameters.quote_replies
    expected_precalc_quote_replies = expected_parameters.precalc_quote_replies
    expected_user_mode_time = expected_parameters.user_mode_time
    expected_modify_order_replies = expected_parameters.modify_order_replies
    expected_gc_number_of_collections = expected_parameters.gc_number_of_collections

    #Don't proceed if scenario is not present in the batch
    scenarios = batch.scenarios.all()
    for scenario in scenarios:
        if scenario.name in scenario_name_eqtrading:
            with session_maker.asgard_read_uncommited_session_provider.get_session () as session:
                # check if error/fail count in the batch
                query = session.query (db_wrapper.ReportVersionScenario.sc_name)
                query = query.filter (db_wrapper.ReportVersionScenario.br_id == batch.id)
                # Added filter to remove 'pending' scenario implementation
                query = query.filter (db_wrapper.ReportVersionScenario.sc_impl == None)            
        
                error_scenarios_query = query.filter (db_wrapper.ReportVersionScenario.sc_status > 1)
                error_scenarios = error_scenarios_query.all()
                error_scnames= []
                for s in error_scenarios:
                    error_scnames.append(s.sc_name)
                if  not (scenario.name in error_scnames):
                    step = scenario.steps.filter_by (fixture = "experimental.MeasureQuoting").first()
                    quote_replies_column = step.columns.filter_by (name = "NbrOfEnterQuoteReplies").first ()
                    precalc_quote_replies_column = step.columns.filter_by (name = "NbrOfEnterPrecalculatedQuoteReplies").first ()
                    modify_order_replies_column = step.columns.filter_by (name = "NbrOfModifyOrderReplies").first ()
                    quote_replies = quote_replies_column.cells[0].f_actual
                    precalc_quote_replies = precalc_quote_replies_column.cells[0].f_actual
                    
                    modify_order_replies = modify_order_replies_column.cells[0].f_actual
                    # After_Quoting_General
                    step = scenario.steps.filter_by (label = "After_Quoting_General").first()
                    user_mode_time_column = step.columns.filter_by (name = "UserModeTime").first ()
                    user_mode_time = user_mode_time_column.cells[0].f_actual
                    user_gc_number_of_collections = step.columns.filter_by (name = "GcNumberOfCollections").first ()
                    gc_number_of_collections = user_gc_number_of_collections.cells[0].f_actual
                    
                    passing_parameters = []
                    failing_parameters = []
        
                    temp_param_details = ['NbrOfEnterQuoteReplies','>'+str(expected_quote_replies),round(quote_replies,2)]
                    if quote_replies < expected_quote_replies:
                        failing_parameters.append(temp_param_details)
                    else:
                        passing_parameters.append(temp_param_details)
        
                    temp_param_details = ['NbrOfEnterPrecalculatedQuoteReplies','<'+ str(expected_precalc_quote_replies),round(precalc_quote_replies,2)]
                    if precalc_quote_replies > expected_precalc_quote_replies:
                        failing_parameters.append(temp_param_details)
                    else:
                        passing_parameters.append(temp_param_details)
        
                    temp_param_details = ['UserModeTime','<'+str(expected_user_mode_time),round(user_mode_time,2)]
                    if user_mode_time > expected_user_mode_time:
                        failing_parameters.append(temp_param_details)
                    else:
                        passing_parameters.append(temp_param_details)
        
                    temp_param_details = ['NbrOfModifyOrderReplies','>'+ str(expected_modify_order_replies),round(modify_order_replies,2)]
                    if modify_order_replies < expected_modify_order_replies:
                        failing_parameters.append(temp_param_details)
                    else:
                        passing_parameters.append(temp_param_details)
                        
                    temp_param_details = ['GcNumberOfCollections','<'+str(expected_gc_number_of_collections),round(gc_number_of_collections,2)]
                    if gc_number_of_collections > expected_gc_number_of_collections:
                        failing_parameters.append(temp_param_details)
                    else:
                        passing_parameters.append(temp_param_details)
                        
                    if failing_parameters:            
                        subject = 'EqTrading alert for "%s", on build: %s.%s.%s'%(batch.name, version_data.main,version_data.sub,version_data.bn)
                        from_email = 'donotreply@tqa.corp'
                        tos = expected_parameters.email_list
                        
                        actual_mail_recipient = []
                        if NOTIFIER_DEBUG:
                            actual_mail_recipient = tos
                            tos = debug_mail_ids    
                        else:
                            tos = tos + cc_mail_ids
                                   
                        text_content = 'This is an important message.'
                        mail_response =  render_to_response('eqtrading_notifier.xhtml',
                                                   {'actual_mail_recipient':actual_mail_recipient,
                                                    'failing_parameters':failing_parameters,
                                                    'passing_parameters':passing_parameters,
                                                    'scenario_name':scenario.name
                                                    })
                        msg = EmailMultiAlternatives(subject, text_content, from_email, tos)
                        msg.attach_alternative (mail_response.content, "text/html")
                        #msg.send()
                        mail_obj_list.append(msg)
    return mail_obj_list


##########################################################
#             Analysis for Scenario Failure              #
##########################################################

def scenario_alert(batch):
    mail_obj_list = []
    with session_maker.asgard_read_uncommited_session_provider.get_session () as session:
        # check if error/fail count in the batch
        version = batch.version
        version_name = batch.version.name
        version_data = get_version('PRIME', version_name)

        query = session.query (db_wrapper.ReportVersionScenario)
        query = query.filter (db_wrapper.ReportVersionScenario.br_id == batch.id)
        # Added filter to remove 'pending' scenario implementation
        query = query.filter (db_wrapper.ReportVersionScenario.sc_impl == None)            

        error_scenarios_query = query.filter (db_wrapper.ReportVersionScenario.sc_status == db_wrapper.Status.error)
        error_scenarios = error_scenarios_query.all()
        failure_scenarios_query = query.filter (db_wrapper.ReportVersionScenario.sc_status == db_wrapper.Status.failed)
        failure_scenarios = failure_scenarios_query.all()
        passing_scenarios_query = query.filter (db_wrapper.ReportVersionScenario.sc_status == db_wrapper.Status.passed)

        no_of_failed_scenarios = len(failure_scenarios)
        no_of_error_scenarios = len(error_scenarios)
        no_of_passed_scenarios = passing_scenarios_query.count()

        if no_of_error_scenarios + no_of_failed_scenarios >0:
    
            # getting email id of all the scenario references 
            ref_query = session.query (db_wrapper.ScenarioReference)
            ref_query = ref_query.filter (db_wrapper.ScenarioReference.br_id == batch.id)        

            # last passing build query for each scenario
            last_pass_query = session.query (db_wrapper.ReportVersionScenario)
            last_pass_query= last_pass_query.filter (db_wrapper.ReportVersionScenario.br_name == batch.name)
            last_pass_query= last_pass_query.filter (db_wrapper.ReportVersionScenario.main == version_data.main)
            last_pass_query= last_pass_query.filter (db_wrapper.ReportVersionScenario.sub == version_data.sub)
            last_pass_query = last_pass_query.filter (db_wrapper.ReportVersionScenario.bn < version_data.bn)
            last_pass_query= last_pass_query.filter (db_wrapper.ReportVersionScenario.component == version.component)   
            last_pass_query= last_pass_query.filter (db_wrapper.ReportVersionScenario.comp_type == version.comp_type)                                
            last_pass_query = last_pass_query.filter (db_wrapper.ReportVersionScenario.sc_status == db_wrapper.Status.passed)
            last_pass_query = last_pass_query.order_by (desc (db_wrapper.ReportVersionScenario.bn))

            tempd_email = {}
            
            for error_scenario in error_scenarios:

                temp_error_scenarios = {}
                temp_error_scenarios["name"] = error_scenario.sc_name
                            
                tmp_last_pass_query = last_pass_query.filter (db_wrapper.ReportVersionScenario.sc_name == error_scenario.sc_name)
                last_changed_item = tmp_last_pass_query.first()

                sc_ref_query =  ref_query.filter(db_wrapper.ScenarioReference.sc_name == error_scenario.sc_name)
                ref_item = sc_ref_query.all ()
                
                temp_error_scenarios ['current_build_status'] = 'error'
                
                if last_changed_item is None:
                    temp_error_scenarios ["last_status_change_bn"] = None
                else:
                    temp_error_scenarios["last_status_change_bn"] = last_changed_item.bn
                # In cases when no reference is defined. 
                if ref_item == []:
                    undefined_sc_ref = "undefined_sc_ref"
                    if tempd_email.has_key(undefined_sc_ref):
                        tempd_email[undefined_sc_ref].append(temp_error_scenarios)
                    else:
                        tempd_email[undefined_sc_ref] = []
                        tempd_email[undefined_sc_ref].append(temp_error_scenarios)
                else:
                    for ref in ref_item:
                        if tempd_email.has_key(ref.ref_value):
                            tempd_email[ref.ref_value].append(temp_error_scenarios)
                        else:
                            tempd_email[ref.ref_value] = []
                            tempd_email[ref.ref_value].append(temp_error_scenarios)

            for failure_scenario in failure_scenarios:

                temp_fail_scenarios = {}
                temp_fail_scenarios["name"] = failure_scenario.sc_name
                            
                tmp_last_pass_query = last_pass_query.filter (db_wrapper.ReportVersionScenario.sc_name == failure_scenario.sc_name)
                last_changed_item = tmp_last_pass_query.first()

                sc_ref_query =  ref_query.filter(db_wrapper.ScenarioReference.sc_name == failure_scenario.sc_name)
                ref_item = sc_ref_query.all ()
                
                temp_fail_scenarios ['current_build_status'] = 'failed'
                
                if last_changed_item is None:
                    temp_fail_scenarios ["last_status_change_bn"] = None
                else:
                    temp_fail_scenarios["last_status_change_bn"] = last_changed_item.bn
                # In cases when no reference is defined.
                if ref_item == []:
                    undefined_sc_ref = "undefined_sc_ref"
                    if tempd_email.has_key(undefined_sc_ref):
                        tempd_email[undefined_sc_ref].append(temp_fail_scenarios)
                    else:
                        tempd_email[undefined_sc_ref] = []
                        tempd_email[undefined_sc_ref].append(temp_fail_scenarios)
                else:
                    for ref in ref_item:
                        if tempd_email.has_key(ref.ref_value):
                            tempd_email[ref.ref_value].append(temp_fail_scenarios)
                        else:
                            tempd_email[ref.ref_value] = []
                            tempd_email[ref.ref_value].append(temp_fail_scenarios)           


            
            for key,value in tempd_email.items():
                subject = 'Asgard Scenario error for "%s", on build: %s.%s.%s'%(batch.name, version_data.main,version_data.sub,version_data.bn)
                from_email = 'donotreply@tqa.corp' 
                tos = [key]
                
                actual_mail_recipient = []
                if NOTIFIER_DEBUG:
                    actual_mail_recipient = tos
                    tos = debug_mail_ids
                else:
                    tos = tos + cc_mail_ids
                
                # Sending mail to debug list in case the Scenario has no reference.
                undefined_sc_ref = False
                if key == "undefined_sc_ref":
                        undefined_sc_ref = True
                        tos = debug_mail_ids
                        
                # Restricting response list to 20 scenarios, avoiding long mail.  
                more_notifications = False
                if len(value) > 20 :
                    more_notifications = True
                    value = value[:20]
                    
                text_content = 'This is an important message.'
                mail_response =  render_to_response('scenario_failure_notifier.xhtml',
                                       {'mail_contents':value,
                                        'version':version_data,
                                        'batch':batch,
                                        'version_data':version_data,
                                        'actual_mail_recipient':actual_mail_recipient,
                                        'no_of_error_scenarios':no_of_error_scenarios,
                                        'no_of_failed_scenarios':no_of_failed_scenarios,
                                        'no_of_passed_scenarios':no_of_passed_scenarios,
                                        'more_notifications':more_notifications,
                                        'undefined_sc_ref':undefined_sc_ref
                                        })
                
                msg = EmailMultiAlternatives(subject, text_content, from_email, tos)
                msg.attach_alternative (mail_response.content, "text/html")
                mail_obj_list.append(msg)
                #msg.send()
    return mail_obj_list
    