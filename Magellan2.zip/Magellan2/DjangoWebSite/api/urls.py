'''
Created on 9 apr 2010

@author: laurent.ploix
'''
from django.conf.urls.defaults import patterns

urlpatterns = patterns('DjangoWebSite.api.views',
    (r'^hist_data', 'hist_data'),
    (r'^graph_list', 'graph_list'),
    (r'^spr_shortcut', 'spr_shortcut'),
    (r'^build_comment_shortcut', 'build_comment_shortcut'),
    (r'^get_annotations', 'get_annotations'),
    (r'^build_comments', 'build_comments'),    
    (r'^build_sprs', 'build_sprs'),
    (r'^get_spr_build_maping','get_spr_build_maping'),
    (r'^spr_detailed_list', 'spr_detailed_list'),
    (r'^checkin_detailed_list', 'checkin_detailed_list'),
    (r'^get_spr_release_information', 'get_spr_release_information'),
    (r'^get_versions', 'get_versions'),
    (r'^alerts_list', 'alerts_list'),
    (r'^get_cvc_setup', 'get_cvc_setup'),
    (r'^get_scenario_grid', 'get_scenario_grid'),
    (r'^get_scenario_steps', 'get_scenario_steps'),
    (r'^get_sets', 'get_sets'),
    (r'^get_cell_exception_details', 'get_cell_exception_details'),
    (r'^get_step_row_exception_details', 'get_step_row_exception_details'),
    (r'^batch_uploaded', 'batch_uploaded'),
    (r'^get_unittest_grid', 'get_unittest_grid'),
    (r'^get_unittest_tags', 'get_unittest_tags'),
    (r'^get_unittest_exception', 'get_unittest_exception'),
    )

