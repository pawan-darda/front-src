'''
Created on 1 Aug 2011

@author: pawan
'''
from django.conf.urls.defaults import patterns

urlpatterns = patterns('DjangoWebSite.document.views',
    (r'^spr_document', 'spr_document'),
    (r'^checkin_document', 'checkin_document'),
    (r'^graph_document', 'graph_document')
    )
