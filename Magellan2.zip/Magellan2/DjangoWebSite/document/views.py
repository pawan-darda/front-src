import csv
import reportlab
from django.http import HttpResponse 
from DjangoWebSite.utils import session_maker
from DjangoWebSite import settings
from front_db.asgard_db import db_wrapper
from front_db.fast_db import direct_wrapper

from reportlab.pdfgen import canvas
from reportlab.platypus import *
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib import colors

from front_utils.versions import get_version
from sqlalchemy import desc, and_, or_

__FAST_SERVER = settings.FAST_SERVER

def spr_document (request):
    
    try :
        
        spr_list = set()
        file_name = ""
        build_name = ""
        doc_type = request.GET.get ("doc_type").strip() or None
        build_1 = request.GET.get ("build_1").strip() or None # 2011.1-4.7.541.0....
        build_2 = request.GET.get ("build_2").strip() or None
        #sprs = request.GET.get ("rel_spr").strip() or None
        component = request.GET.get("component", "PRIME").strip().upper()
        
        if build_1 == None and build_2 == None:
            return HttpResponse()
        
        versions = [build_1 and get_version(component, build_1), build_2 and get_version(component, build_2)]
        versions.sort ()
        
        build_nbs = [versions[0] and versions[0].bn, versions[1].bn]

        bldnumber1= build_nbs [0]
    
        # Getting Data table related values
        #sSearch = request.GET.get("sSearch").strip() or None
        sSearch = None

        session = session_maker.get_fast_read_uncommitted_db_session(settings.DEBUG)
        build_number_class = direct_wrapper.get_FAST_class("BuildNumber", session)
        db_query = session.query (build_number_class)
        db_query = db_query.filter_by (major = versions[1].main)
        db_query = db_query.filter_by (minor = versions[1].sub)
        db_query = db_query.filter_by (alt_bnumber = 0)
        
        build_name = build_1.split("-")[0]
        #Single build selected.
        if bldnumber1 is None :
            db_query = db_query.filter(build_number_class.bnumber == build_nbs[1])
            file_name = "SPR_Build_%s_%s" %(build_name,build_nbs[1]) 
        else:
        #Multiple selection
            db_query = db_query.filter(and_(build_number_class.bnumber <= build_nbs[1], 
                                        build_number_class.bnumber > build_nbs[0]))
            file_name = "SPR_Build_%s_%s_to_%s" %(build_name,build_nbs[1],build_nbs[0])
        #@todo: we need to also take the branches into account. For now it does not work.

        spr_bld_mapping = {}
        for bn in db_query:   
            if bn.clean_sprs_included != None:         
                bn_spr_list = set([s.strip () for s in bn.clean_sprs_included.split (";") if s.strip()])
                build_set = set([])
                for spr in bn_spr_list:
                    build_set = set([bn.build_number])
                    if spr_bld_mapping.has_key(spr):
                        spr_bld_mapping[spr].union (build_set)
                    else:
                        spr_bld_mapping[spr]=set (build_set)
                    
                spr_list = spr_list.union(bn_spr_list)
                
        dw_SPR = direct_wrapper.get_FAST_class("1:SPREntry", session)
          
        spr_query = session.query (dw_SPR)
        spr_query = spr_query.filter (dw_SPR.spr_id.in_ (spr_list))
        spr_query = spr_query.filter (dw_SPR.spr_id <> 264097) # generic build spr
        spr_query = spr_query.filter (dw_SPR.spr_id <> 260796) # generic build spr

        # Adding search related queries 
        if sSearch != None:            
            sSearchLst = sSearch.split(" ")
            for isSearch in sSearchLst:
                iSearch = '%' + isSearch + '%'
                spr_query = spr_query.filter(or_(dw_SPR.spr_id.like(iSearch), 
                                                 dw_SPR.component.like(iSearch),
                                                 dw_SPR.severity.like(iSearch), 
                                                 dw_SPR.spr_submitter.like(iSearch), 
                                                 dw_SPR.assigned_to.like(iSearch), 
                                                 dw_SPR.spr_status.like(iSearch), 
                                                 #dw_SPR.tester.like(sSearch),
                                                 dw_SPR.short_description_spr.like(iSearch), 
                                                 dw_SPR.external_spr_description.like(iSearch) ))
                
            #totalFilteredRecords = spr_query.count()
        
        spr_query = spr_query.order_by(dw_SPR.spr_id)
        #sprs = spr_query[int(iDisplayStart):int(iDisplayStart)+int(iDisplayLength)]
        
        sprs = spr_query.all()
        data = []
        header,header_keys = spr_headers()

        for spr in sprs:
            
            spr_txt = ",".join(spr_bld_mapping[spr.spr_id])
            values = []
            for attr in header_keys:
                values.append(str (getattr (spr, attr)))
            values.append(spr_txt)
            data.append(values)
            
        header.append("Build Numbers")
        data.insert(0,header)
        
        if doc_type == "csv":
        
            response = HttpResponse(mimetype='text/csv')
            t_fn = file_name + ".csv"
            response['Content-Disposition'] = 'attachment; filename=' + t_fn
    
            writer = csv.writer(response)    
            for rowvalu in data:
                writer.writerow(rowvalu)
        
        elif doc_type == "pdf":
    
            response = HttpResponse(mimetype='application/pdf')    
            t_fn = file_name + ".pdf"
            response['Content-Disposition'] = 'attachment; filename=' + t_fn

            doc = SimpleDocTemplate(response)
            styles = getSampleStyleSheet()
            content = []

            for data_ind,rowvalu in enumerate(data):
                if not data_ind == 0:
                    for col_ind, column in enumerate(rowvalu):
                        if col_ind == 0:
                            content.append(Paragraph("SPR " + str(column), styles['Heading2']))
                        else:
                            content.append(Paragraph( header [col_ind]+ " : " + str(column), styles['Heading4']))
                        
            doc.build(content)

        return response

    except Exception, e :
        print e
    finally:
        if session is not None : session.close()

def spr_headers():

    disp_attrs = ["SPR ID",
                  "Date Created", 
                  "Componenent",
                  "Severity",
                  "Submitter",
                  "Assigned",
                  "Tester", 
                  "Status",
                  "Title" ]
    
    attrs = ["spr_id",
             "created", 
             "component",
             "severity",
             "spr_submitter",
             "assigned_to",
             "tester", 
             "spr_status",
             "short_description_spr" ]
    
    return disp_attrs, attrs

def checkin_document (request):
    
    try :
        file_name = ""
        build_name = ""
        doc_type = request.GET.get ("doc_type").strip() or None        
        build_1 = request.GET.get ("build_1").strip() or None # 2011.1-4.7.541.0....
        build_2 = request.GET.get ("build_2").strip() or None
        sprs = request.GET.get ("rel_spr").strip() or None
        filter_data = request.GET.get ("filter_data").strip() or None
        component = request.GET.get("component", "PRIME").strip().upper()
        
        if build_1 == None and build_2 == None:
            return HttpResponse()
        
        released_sprs = {}
        if sprs != None: 
            released_sprs = dict( [str(ite),1] for ite in sprs.split("%2C"))
      
        #sSearch = request.GET.get("sSearch").strip() or None
        sSearch = None
        
        versions = [build_1 and get_version('PRIME', build_1), build_2 and get_version('PRIME', build_2)]
        versions.sort ()
        
        build_nbs = [versions[0] and versions[0].bn, versions[1].bn]
        bldnumber1= build_nbs [0]

        session = session_maker.get_asgard_read_uncommitted_db_session()
        db_query = session.query(db_wrapper.RevLogs,db_wrapper.Version.name)
        db_query = db_query.join (db_wrapper.Version)
        db_query = db_query.filter (db_wrapper.Version.main == versions[1].main)
        db_query = db_query.filter (db_wrapper.Version.sub ==  versions[1].sub)
        db_query = db_query.filter (db_wrapper.Version.abn == 0)
        db_query = db_query.filter (db_wrapper.RevLogs.spr <> 264097) # generic build spr
        db_query = db_query.filter (db_wrapper.RevLogs.spr <> 260796) # generic build spr
        
        build_name = build_1.split("-")[0]
        if bldnumber1 is None :
            db_query = db_query.filter(db_wrapper.Version.bn == build_nbs[1])
            file_name = "Checkins_Build_%s_%s" %(build_name,build_nbs[1])
        else:
        #Multiple selection 
            db_query = db_query.filter(and_(db_wrapper.Version.bn <= build_nbs[1], 
                                        db_wrapper.Version.bn > build_nbs[0]))
            file_name = "Checkins_Build_%s_%s_to_%s" %(build_name,build_nbs[1],build_nbs[0])

        if sSearch != None:
            sSearchLst = sSearch.split(" ")
            for isSearch in sSearchLst:
                iSearch = '%' + isSearch + '%'
                db_query = db_query.filter(or_(db_wrapper.RevLogs.spr.like(iSearch),
                                               db_wrapper.RevLogs.branch.like(iSearch),
                                               db_wrapper.RevLogs.file_name.like(iSearch),
                                               db_wrapper.RevLogs.cc_ver_nb.like(iSearch), 
                                               db_wrapper.RevLogs.user_login.like(iSearch),
                                               db_wrapper.RevLogs.dat.like(iSearch),
                                               db_wrapper.RevLogs.comment.like(iSearch)))

        db_query = db_query.order_by(db_wrapper.RevLogs.spr)

        data = []

        releaseFound = False
        filterData = False
        
        if len(released_sprs) != 0:
            releaseFound = True
        
        if filter_data =='1':
            filterData = True

        checkins = db_query.all()

        disp_header, header = checkin_headers()
     
        for checkin in checkins:
            checkin_ver_name = str(checkin.name).strip().split("-")[1]
            checkin_date= str(checkin.RevLogs.dat).strip().split(" ")[0]
            spr_id = str(checkin.RevLogs.spr)
            includeSpr = True 
            
            tmpLst = []
            
            if filterData and releaseFound:
                if released_sprs.has_key(spr_id):
                    includeSpr = False

            if includeSpr:
                for attr in header:
                    tmpLst.append(str (getattr (checkin.RevLogs, attr)))
                tmpLst.append(checkin_ver_name)
                tmpLst.append(checkin_date)
                data.append(tmpLst)

        disp_header.append("Build")
        disp_header.append("Checkin Date")
        data.insert(0,disp_header)
        
        if doc_type == "csv":
        
            response = HttpResponse(mimetype='text/csv')
            t_fn = file_name + ".csv"
            response['Content-Disposition'] = 'attachment; filename=' + t_fn
    
            writer = csv.writer(response)    
            for rowvalu in data:
                writer.writerow(rowvalu)
        
        elif doc_type == "pdf":
    
            response = HttpResponse(mimetype='application/pdf')                
            t_fn = file_name + ".pdf"
            response['Content-Disposition'] = 'attachment; filename=' + t_fn
            
            doc = SimpleDocTemplate(response)
            styles = getSampleStyleSheet()
            content = []

            for data_ind,rowvalu in enumerate(data):
                if not data_ind == 0:
                    for col_ind, column in enumerate(rowvalu):
                        if col_ind == 0:
                            content.append(Paragraph(str(column), styles['Heading2']))
                        else:
                            content.append(Paragraph( disp_header [col_ind]+ " : " + str(column), styles['Heading4']))
                        
            doc.build(content)

        return response

    except Exception, e :
        print e
        response = HttpResponse()
        return response
    finally:
        if session is not None : session.close()

def checkin_headers():

    disp_attrs = ["File Name",
                  "SPR ID",
                  "Branch",
                  "Directory Name",
                  "Node", 
                  "User",
                  "Comment" ]
    
    attrs = ["file_name",
             "spr",
             "branch",
             "dir_name",
             "cc_ver_nb",
             "user_login",
             "comment" ]
    
    return disp_attrs, attrs

def graph_document (request):
    
    try :
        session = None
    except Exception, e :
        print e
    finally:
        if session is not None : session.close()        
        
