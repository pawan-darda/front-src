'''
Created on 4 aug 2010

@author: Laurent.Ploix
'''
from django import template

register = template.Library()

def cell_class (cell):
    if cell.column.kind == 'o':
        result = "scenario_content_cell_out" 
    else:
        result = "scenario_content_cell_in"
    return result

from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe
def label_column_table (data, autoescape=None):
    if autoescape:
        esc = conditional_escape
    else:
        esc = lambda x: x
    all_labels_columns = set((d[1], d[2]) for d in data)
    all_columns = list (set(d[2] for d in data))
    all_columns.sort ()
    all_labels = list (set(d[1] for d in data))
    all_labels.sort ()
    result = "<div class='ui-widget'>\n"
    result = result + "<table class='shortcuts'>\n" #<caption class='shortcut'>%s.%s</caption>"%(esc (data[0][3]), esc (data[0][4]))
    result = result + "<thead><tr><th/>\n"
    for column in all_columns :
        result = result + "<th><span class=\"ver_header\">\n"
        result = result + esc (column)
        result = result + "</span></th>\n"
    result = result + "</tr></thead><tbody>\n"
    for label in all_labels:
        result = (result + "<tr><td>" + esc (label) + "</td>\n")
        for column in all_columns :
            result = result + "<td class='shortcut'>\n"
            if (label, column) in all_labels_columns :
                result = result + ("<a href='graph?ql=name:%%22%s%%22&amp;qc=name:%%22%s%%22&amp;qs=name:%%22%s%%22&amp;qv=main:%s sub:%s'>"%(esc(label), esc(column), esc (data[0][0]), esc (data[0][3]), esc (data[0][4])))
                result = result + "<div class='ui-icon ui-icon-circle-plus'>\n"
                result = result + "</div>\n" 
                result = result + "</a>\n" 
            result = result + "</td>\n"
        result = result + "</tr>\n"
    result = result + "</tbody></table>\n"
    result = result + "</div>\n"
    return mark_safe(result)

def status_class (o):
    try :
        try :
            status = int (o)
        except ValueError :
            status = o.status
        except TypeError :
            status = o.status
        if status == -1:  return "unprocessed"
        elif status == 0: return "skipped"
        elif status == 1: return 'passed' 
        elif status == 2: return 'failed' 
        elif status == 3: return 'error' 
        elif status == 4: return 'crash'
    except KeyboardInterrupt :
        raise
    except Exception:
        pass 
    return "unknown"

def status_css_class (o):
    """
    Returns the new class names for the css on version page
    """
    try :
        try :
            status = int (o)
        except ValueError :
            status = o.status
        except TypeError :
            status = o.status
        if status == -1:  return "unprocessed"
        elif status == 0: return "scenario_norun"
        elif status == 1: return 'scenario_passing' 
        elif status == 2: return 'scenario_failing' 
        elif status == 3: return 'scenario_error' 
        elif status == 4: return 'crash'
    except KeyboardInterrupt :
        raise
    except Exception:
        pass 
    return "unknown"

def has_error_info (o):
    """
    Returns if the given cell, row etc has any displayable error info
    """
    try :
        if o.exception is None:
            return False
        try :
            status = int (o)
        except ValueError :
            status = o.status
        except TypeError :
            status = o.status
        if status in  [2, 3, 4]: 
            return True 
    except KeyboardInterrupt :
        raise
    except Exception:
        pass 
    return False

def spaceify (name):
    """Create a scenario name that contains spaces so that it can be better displayed"""
    s = name.replace ("_", " ")
    if s.endswith (".xls") : s = s[:-4]
    elif s.endswith (".xlsx") : s = s[:-5]
    import re
    s = re.sub('((?=[A-Z][a-z])|(?<=[a-z])(?=[A-Z]))', ' ', s)
    while "  " in s: # Ok, could be better and this is really stupid impl
        # but this should really not happen except one or twice
        s = s.replace ("  ", " ")
    return s.strip()

def count_version_scenarios (version):
    return sum ([batch.scenarios.count() for batch in version.batch_runs])

def version_status(version):
    try :
        return max ([batch.status for batch in version.batch_runs])
    except ValueError:
        return 0

def cell_value (cell):
    if cell.column.kind == 'i':
        if cell.f_expected is not None :
            return str (cell.f_expected)
        return cell.s_expected
    else:
        if cell.f_actual is not None: 
            result = str (cell.f_actual)
        else : result = cell.s_actual
    if cell.status == 1 : 
        return result
    if cell.f_expected is not None :
        return "%s (%s)"%(result, str (cell.f_expected))
    return "%s (%s)"%(result, cell.s_expected)

def get (d, key):
    return d[key]

register.filter('label_column_table', label_column_table)
register.filter('get', get)
register.filter('cell_class', cell_class)
register.filter('cell_value', cell_value)
register.filter('status_class', status_class)
register.filter('status_css_class', status_css_class)
register.filter('count_version_scenarios', count_version_scenarios)
register.filter('version_status', version_status)
register.filter('spaceify', spaceify)
register.filter('has_error_info', has_error_info)
