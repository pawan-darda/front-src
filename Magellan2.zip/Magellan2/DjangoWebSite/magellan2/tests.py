
from django.test import TestCase
from DjangoWebSite.magellan2.forms.Forms import VersionForm, ScenarioForm, GraphForm
from DjangoWebSite.magellan2.forms.Forms import QHandler
from lxml import etree
from DjangoWebSite.magellan2.views import scenario, version, graph, shortcuts
import DjangoWebSite.utils.session_maker as session_maker
from StringIO import StringIO
import re

class FakeRequest (object):
    def __init__ (self, **kwargs):
        self.data = kwargs
    @property
    def GET (self):
        return self.data
    
    @property
    def META(self):
        return self.data
    
    @property
    def path(self):
        return ""
    
class FakeAsgardDbSession (object):
    def query (self, *args, **kwargs):
        return FakeAsgardQuery ()
    
class FakeAsgardQuery (object):
    def join (self, *args, **kwargs):
        return self 
    def distinct (self, *args, **kwargs):
        return self 
    def filter (self, *args, **kwargs):
        return self 
    def order_by (self, *args, **kwargs):
        return self 
    def filter_by (self, *args, **kwargs):
        return self 
    def count (self, *args, **kwargs):
        return 0 
    def all (self, *args, **kwargs):
        return [] 
    def first (self, *args, **kwargs):
        return None 
    def __getitem__ (self, i):
        return []

class ViewsTests (TestCase):
    """
    A set of sanity check for views; so that we make sure they are HTML compliant
    Test is done with very, very simple request. 
    
    @todo This test should be done against a local DB loaded with BR instead. 
    """

    def test_scenario_with_simple_request_is_html (self):
        page = scenario (FakeRequest(qv="main:4 sub:7 bn:200", 
                                    qs="name:%22Benchmark_CalcAPI_EquityDerivatives_BenchLevel3.xls%22",
                                    QUERY_STRING="",
                                    HTTP_HOST=""))
        parser = etree.HTMLParser(recover=False)
        etree.parse(StringIO(page.content), parser)

    def test_graph_with_simple_request_is_html (self):
        page = graph (FakeRequest(qv="sub:7 bn:200", 
                                                 qs="name:%22Benchmark_CalcAPI_EquityDerivatives_BenchLevel3.xls%22", 
                                                 qc='used_cpu_s', 
                                                 ql='diff before',
                                                 QUERY_STRING="",
                                                 HTTP_HOST=""))
        parser = etree.HTMLParser(recover=False)
        etree.parse(StringIO(page.content), parser)

    def test_shortcut_is_html (self):
        page = shortcuts (FakeRequest())
        parser = etree.HTMLParser(recover=False)
        etree.parse(StringIO(page.content), parser)

    def test_version_with_simple_request_is_html (self):
        page = version (FakeRequest(qv="sub:7 bn:200", ))
        parser = etree.HTMLParser(recover=False)
        etree.parse(StringIO(page.content), parser)

class TemplatesXmlTest (TestCase):
    """ Would be better to test this is html instead.
    This test is not _mandatory_ as such, it's more a way to prevent from broken templates
    There is a drawback: sometimes the template is _not_ xml on purpose (special characters)
    Solutions welcomed. """
    
    clean_template_re = "{%([^%]|%[^}])*%}"
    trailing_comma_re = r"\,\s*[\)}]" 
    parser = etree.HTMLParser(recover=False)
    @staticmethod
    def template_to_html_only (template):
        return StringIO ("".join (re.split (TemplatesXmlTest.clean_template_re, template.read())))
    
    def test_contains_trailing_comma (self):
        """Meta test checking the regexp works fine"""
        template = r"whatever ,} whatever"
        self.assertNotEqual (None, re.search (self.trailing_comma_re, template))
        template = r"whatever ,) whatever"
        self.assertNotEqual (None, re.search (self.trailing_comma_re, template))
        template = r"whatever , } whatever"
        self.assertNotEqual (None, re.search (self.trailing_comma_re, template))
        template = r"whatever , ) whatever"
        self.assertNotEqual (None, re.search (self.trailing_comma_re, template))
    
    def test_index_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/index.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_index_template_is_html (self):
        template = open ("magellan2/templates/index.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)

    def test_build_comments_template_is_html (self):
        template = open ("api/templates/build_comment.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)

    def test_build_sprs_template_is_html (self):
        template = open ("api/templates/build_sprs.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)

    def test_build_sprs_list_template_is_html (self):
        template = open ("api/templates/spr_detailed_list.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_build_sprs_list_template_has_no_trailing_comma (self):
        template = open ("api/templates/spr_detailed_list.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_scenario_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/scenario.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_scenario_template_is_html (self):
        template = open ("magellan2/templates/scenario.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_spr_detailed_list_template_is_html (self):
        template = open ("api/templates/spr_detailed_list.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_overview_template_is_html (self):
        template = open ("magellan2/templates/overview.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_version_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/version.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_version_template_is_html (self):
        template = open ("magellan2/templates/version.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_graph_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/graph.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_graph_template_is_html (self):
        template = open ("magellan2/templates/graph.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_shortcut_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/shortcut.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_shortcut_template_is_html (self):
        template = open ("magellan2/templates/shortcut.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_base_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/base.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_base_template_is_html (self):
        template = open ("magellan2/templates/base.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_wall_template_has_no_trailing_comma (self):
        template = open ("magellan2/templates/wall.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_wall_template_is_html (self):
        template = open ("magellan2/templates/wall.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
            
    def test_asg_scenario_template_has_no_trailing_comma (self):
        template = open ("portlets/templates/asg_scenario.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_asg_scenario_is_html (self):
        template = open ("portlets/templates/asg_scenario.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)        
        
    def test_open_wall_template_has_no_trailing_comma (self):
        template = open ("portlets/templates/open_wall.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_open_wall_is_html (self):
        template = open ("portlets/templates/open_wall.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)   

    def test_perf_graph_template_has_no_trailing_comma (self):
        template = open ("portlets/templates/perf_graph.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_perf_graph_is_html (self):
        template = open ("portlets/templates/perf_graph.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)
        
    def test_portlet_template_has_no_trailing_comma (self):
        template = open ("portlets/templates/portlet.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_portlet_is_html (self):
        template = open ("portlets/templates/portlet.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)

    def test_unittest_template_has_no_trailing_comma (self):
        template = open ("portlets/templates/unittest_results.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_unittest_is_html (self):
        template = open ("portlets/templates/unittest_results.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)        

    def test_buildstatus_template_has_no_trailing_comma (self):
        template = open ("portlets/templates/build_status.xhtml")
        self.assertEqual (None, re.search (self.trailing_comma_re, template.read()))

    def test_buildstatus_is_html (self):
        template = open ("portlets/templates/build_status.xhtml")
        etree.parse (self.template_to_html_only (template), self.parser)  

class VersionFormTest (TestCase):
    def testFormHasQvField (self):
        f = VersionForm ()
        f.fields ["qv"]
        
    def testFindsPosFreeFields (self):
        f = QHandler (q="free ab:5 field -pipo -c:54")
        self.assertEquals (["free", "field"], f.pos_freewords)
    
    def testFindsPosFreeFieldsWithQuotes (self):
        f = QHandler (q='"free" ab:5 field -pipo -c:54')
        self.assertEquals (["free", "field"], f.pos_freewords)
    
    def testFindsNegFreeFields (self):
        f = QHandler (q="free ab:5 field -foo -c:54 -bar")
        self.assertEquals (["foo", "bar"], f.neg_freewords)
    
    def testFindsPosKeyFields (self):
        f = QHandler (q="free ab:5 field -foo cd:654 -c:54 -bar")
        self.assertEquals ({"ab":"5", "cd":"654"}, f.pos_keywords)
    
    def testFindsNegKeyFields (self):
        f = QHandler (q="free ab:5 field -foo cd:654 -c:54 -bar -boo:poi")
        self.assertEquals ({"c":"54", "boo":"poi"}, f.neg_keywords)  
    
class ScenarioFormTest (VersionFormTest):
    def testFormHasQvField (self):
        f = ScenarioForm ()
        f.fields ["qs"]
        f.fields ["qv"]
        f.fields ["qsid"] # This one will go as soon as we introduce a the ajax way to display the content of the scenario. 
        
class GraphFormTest (ScenarioFormTest):
    def testFormHasQlField (self):
        f = GraphForm ()
        f.fields ["ql"]

    def testFormHasQcField (self):
        f = GraphForm ()
        f.fields ["qc"]

class TagsTest (TestCase):
    def test_status_class_filter (self):
        from templatetags.asgard_tags import status_class
        class C (object):
            status = None
        C.status =-1
        self.assertEquals ("unprocessed", status_class(C()))
        C.status =0
        self.assertEquals ("skipped", status_class(C()))
        C.status =1
        self.assertEquals ("passed", status_class(C()))
        C.status =2
        self.assertEquals ("failed", status_class(C()))
        C.status =3
        self.assertEquals ("error", status_class(C()))
        C.status =4
        self.assertEquals ("crash", status_class(C()))
        C.status =5
        self.assertEquals ("unknown", status_class(C()))
        
    def test_status_class_filter_with_type_error (self):
        from templatetags.asgard_tags import status_class
        self.assertEquals ("unknown", status_class(object))
        
    def test_status_emptystring (self):
        from templatetags.asgard_tags import status_class
        self.assertEquals ("unknown", status_class(""))
        
    def test_spaceify_with_undercores (self):
        from templatetags.asgard_tags import spaceify
        self.assertEquals ("abc", spaceify ("abc"))
        self.assertEquals ("a bc", spaceify ("a_bc"))
        self.assertEquals ("a b c", spaceify ("a_b c"))
        self.assertEquals ("a b c", spaceify ("a_b  c"))
        
    def test_spaceify_with_xls (self):
        from templatetags.asgard_tags import spaceify
        self.assertEquals ("abc", spaceify ("abc.xls"))
        self.assertEquals ("abc", spaceify ("abc.xls"))
        self.assertEquals ("abc", spaceify (" abc .xls"))
        self.assertEquals ("abc", spaceify (" abc  .xls"))

    def test_spaceify_with_capital_letters (self):
        from templatetags.asgard_tags import spaceify
        self.assertEquals ("Abc", spaceify ("Abc"))
        self.assertEquals ("a Bc", spaceify ("aBc"))
