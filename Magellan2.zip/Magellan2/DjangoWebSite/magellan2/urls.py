'''
Created on 9 apr 2010

@author: laurent.ploix
'''
from django.conf.urls.defaults import patterns

urlpatterns = patterns('DjangoWebSite.magellan2.views',
    (r'^version$', 'version'),
    (r'^scenario$', 'scenario'),
    (r'^graph$', 'graph'),
    (r'^shortcuts$', 'shortcuts'),
    (r'^overview$', 'overview'),
    (r'^wall$', 'wall'),
    (r'^home$', 'index'),
    (r'^$', 'index'),
    
    )

