# Django settings for Magellan2 project.
import os 
from datetime import datetime
now = datetime.now ()
START_TAG = "%d%02d%02d%02d%02d"%(now.year, now.month, now.day, now.hour, now.minute)


ON_SERVER = os.environ["COMPUTERNAME"].startswith ("W2003-VM08")

NOTIFIER_DEBUG = True
DEBUG = not ON_SERVER
#DEBUG=False
QuickBuildLogPath =  'Debug' if DEBUG else  'D:\UpdateQuickBuildStatusLog\qb_status.txt'
TEMPLATE_DEBUG = DEBUG
FAST_SERVER = 'emeastofast01'
FAST_SERVER_DEBUG = 'emeastofast02'

#PROFILE_LOG_BASE = 'D:/DjangoLogs'

ADMINS = (
    # ('Your Name', 'your_email@domain.com'),
)

MANAGERS = ADMINS

def in_site_name (filename):
    mydir = os.path.split (__file__)[0]
    new_name = os.path.join(mydir, filename)
    return new_name

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3', # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': in_site_name ('db\\sqlite.db') if not ON_SERVER else r"C:\data\magellan\sqlite.db",
        'USER': '',                      # Not used with sqlite3.
        'PASSWORD': '',                  # Not used with sqlite3.
        'HOST': '',                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
    }
}

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'Europe/Stockholm'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale
USE_L10N = True

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
MEDIA_ROOT = ''

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash if there is a path component (optional in other cases).
# Examples: "http://media.lawrence.com", "http://example.com/media/"
MEDIA_URL = ''

# URL prefix for admin media -- CSS, JavaScript and images. Make sure to use a
# trailing slash.
# Examples: "http://foo.com/media/", "/media/".
ADMIN_MEDIA_PREFIX = '/media/'

# Make this unique, and don't share it with anybody.
SECRET_KEY = '&tm$_6*7b+pd&-u=f)(e$s)k59ds8-5ac)6x0&fn@v1)$$76mo'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
#     'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.csrf.CsrfResponseMiddleware',
)

ROOT_URLCONF = 'DjangoWebSite.urls'

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    in_site_name ('magellan2/templates'),
    in_site_name ('api/templates'),
    in_site_name ('default/templates'),
    in_site_name('portlets/templates'),
    in_site_name('tech/templates'),
    in_site_name('api/templates/notifiers')
    )

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    # Uncomment the next line to enable the admin:
    'django.contrib.admin',
    'DjangoWebSite.magellan2',
    'DjangoWebSite.default',
)

EMAIL_HOST = "10.254.66.32"
EMAIL_PORT = 25