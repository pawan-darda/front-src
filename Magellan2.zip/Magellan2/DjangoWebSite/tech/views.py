import json
from django.http import HttpResponse, HttpResponseServerError
from DjangoWebSite import settings
from front_db.fast_db import direct_wrapper
from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from front_db.magellan_db.mag_db_wrapper import Wall, Portlet
from DjangoWebSite.utils import session_maker
__FAST_SERVER = settings.FAST_SERVER
    

def batch(request):
    batch_id = request.GET.get ("br_id")
    return render_to_response('tech_batch.xhtml')

def index(request):
    return HttpResponse("got the page up")
