

from django.conf.urls.defaults import include, patterns
#from DjangoSite.magellan2.models import BuildBotBuilder, BuildBotBuilderStatus

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
#admin.site.register(BuildBotBuilder)
#admin.site.register(BuildBotBuilderStatus)



admin.autodiscover()
from DjangoWebSite import settings

    # Example:
    # (r'^DjangoSite/', include('DjangoSite.foo.urls')),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs' 
    # to INSTALLED_APPS to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
urlpatterns = patterns('',
    # The http://<server>/magellan2 points to the urls described in this urls.py file 
    (r'^magellan2/', include('DjangoWebSite.magellan2.urls')),

    # The http://<server>/api points to the urls described in this urls.py file
    # The api part is supposed to be the place where we get raw data, such as csv, jsojm or similar. 
    (r'^api/', include('DjangoWebSite.api.urls')),
    (r'^document/', include('DjangoWebSite.document.urls')),
    (r'^tech/', include('DjangoWebSite.tech.urls')),
    (r'^portlets/', include('DjangoWebSite.portlets.urls')),
    (r'^admin/(.*)', admin.site.root),
    (r'^$', 'DjangoWebSite.default.views.index'),
)

def in_site_name (filename):
    import os
    mydir = os.path.split (__file__)[0]
    new_name = os.path.join(mydir, filename)
    return new_name


if not settings.ON_SERVER :
        urlpatterns += patterns('',
        (r'^static/(?P<path>.*)$', 'django.views.static.serve',
            {'document_root': in_site_name ('static')}),
    )

from django.conf.urls.defaults import *
handler404 = "DjangoWebSite.magellan2.views.exception404"
handler500 = "DjangoWebSite.magellan2.views.exception500"